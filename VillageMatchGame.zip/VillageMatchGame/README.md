# Village Match Game - تعليمات

## خطوات تشغيل المشروع:

1. قم بفتح مشروعك في أي محرر Dart/Flutter (Notepad++, VS Code, Dcoder, AIDE).
2. ضع ملف `main.dart` داخل مجلد `lib`.
3. ضع ملف `pubspec.yaml` في جذر المشروع.
4. أضف `firebase_rules.txt` واحتفظ به للرجوع.
5. ربط المشروع بـ Firebase:
   - أنشئ مشروع Firebase جديد.
   - أضف تطبيق Android، حمل `google-services.json` وضعه داخل `android/app/`.
   - فعل Email/Password في Authentication.
   - أنشئ مجموعات Firestore: daily, submissions, users.
6. ربط المشروع بـ AdMob:
   - أنشئ وحدات إعلانات Banner وInterstitial وRewarded.
   - اضبط Content Rating = G.
   - يمكنك استخدام إعلانات محلية (house ads) إذا رغبت.
7. قم برفع المشروع على خدمة Build Online (مثل Codemagic أو Appcircle) لبناء APK.
8. بعد بناء APK، يمكنك تثبيته على الهاتف وتجربة اللعبة.
9. المشرف الوحيد هو أنت: تختار صورة التحدي اليومي، الجوائز، والإعلانات.